//
// Main.c
// BaseEntitlementLoader
//
// Created by Anonym on 15.09.26.
//

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <LindChain/ProcEnvironment/Surface/kxld/image.h>
#include <LindChain/ProcEnvironment/Utils/klog.h>
#include <LindChain/ProcEnvironment/Surface/libkern/patch.h>
#include <LindChain/ProcEnvironment/Surface/lock.h>
#include <CoreFoundation/CoreFoundation.h>
#include <pthread.h>

typedef struct entitlement_schema_entry {
	CFStringRef key;
	CFTypeID expected_type;
	struct entitlement_schema_entry *next;
} entitlement_schema_entry_t;

static entitlement_schema_entry_t *schema = NULL;
static entitlement_schema_entry_t *lastSchema = NULL;
static pthread_rwlock_t lock;

extern kern_return_t BaseEntitementLoaderAddEntry(CFStringRef key, CFTypeID expected_type)
{
	PTHREAD_RWLOCK_DEBUG_IMP_WRLOCK(&lock);
	if(schema == NULL)
	{
		schema = calloc(1, sizeof(entitlement_schema_entry_t));
		schema->key = CFRetain(key);
		schema->expected_type = expected_type;
		lastSchema = schema;
	}
	else
	{
		lastSchema->next = calloc(1, sizeof(entitlement_schema_entry_t));
		lastSchema->next->key = CFRetain(key);
		lastSchema->next->expected_type = expected_type;
		lastSchema = lastSchema->next;
	}
	PTHREAD_RWLOCK_DEBUG_IMP_UNLOCK(&lock);
	return KERN_SUCCESS;
}

static bool array_is_all_strings(CFArrayRef arr)
{
	CFIndex n = CFArrayGetCount(arr);
	for(CFIndex i = 0; i < n; i++)
	{
		CFTypeRef e = CFArrayGetValueAtIndex(arr, i);
		if(!e || CFGetTypeID(e) != CFStringGetTypeID())
		{
			return false;
		}
	}
	return true;
}

LIBKERN_PATCH(CFDictionaryRef, trust_identity_validate_entitlements, (CFStringRef executablePath, CFDictionaryRef entitlements),{
	CFDictionaryRef validated = trust_identity_validate_entitlements__orig(executablePath, entitlements);
	if(validated == NULL)
	{
		return NULL;
	}
	
	CFMutableDictionaryRef validatedMutable = CFDictionaryCreateMutableCopy(kCFAllocatorDefault, 0, validated);
	CFRelease(validated);
	if(validatedMutable == NULL)
	{
		return NULL;
	}
	
	PTHREAD_RWLOCK_DEBUG_IMP_RDLOCK(&lock);
	entitlement_schema_entry_t *currentSchema = schema;
	while(currentSchema != NULL)
	{
		CFTypeRef val = CFDictionaryGetValue(entitlements, currentSchema->key);
		if(val == NULL)
		{
			currentSchema = currentSchema->next;
			continue;
		}
		
		if(CFGetTypeID(val) != currentSchema->expected_type)
		{
			currentSchema = currentSchema->next;
			continue;
		}
		
		if(currentSchema->expected_type == CFArrayGetTypeID())
		{
			if(!array_is_all_strings((CFArrayRef)val))
			{
				currentSchema = currentSchema->next;
				continue;
			}
		}
		
		klog_log("org.emexlabs.BaseEntitlementLoader", "inserting loaded entitlement for key %@, because it is defined in signature blob of executable %@", (__bridge NSString*)currentSchema->key, (__bridge NSString*)executablePath);
		CFDictionarySetValue(validatedMutable, currentSchema->key, val);
		currentSchema = currentSchema->next;
	}
	PTHREAD_RWLOCK_DEBUG_IMP_UNLOCK(&lock);
	
	return validatedMutable;
});

kern_return_t kinit(void)
{
	if(pthread_rwlock_init(&(lock), NULL) != 0)
	{
		return KERN_FAILURE;
	}
	klog_log("org.emexlabs.BaseEntitlementLoader", "initialized rwlock");
	
	LIBKERN_INSTALL_PATCH(trust_identity_validate_entitlements);
	klog_log("org.emexlabs.BaseEntitlementLoader", "installed trust_identity_validate_entitlements patch");
	return KERN_SUCCESS;
}

EXPORT_KSURFACE_MODULE({
	.magic = KSURFACE_KMOD_MAGIC,
	.abi_version = KSURFACE_KMOD_ABI_VERSION,
	.identifier = "org.emexlabs.BaseEntitlementLoader",
	.version = KMOD_VERSION(1, 0, 2),
	.flags = KMOD_FLAG_PERSISTENT,
	.dependency_count = 1,
	.init = kinit,
	.deinit = NULL,
	.start = NULL,
	.stop = NULL,
	.dependencies = {
		{
			.identifier = "ksurface",
			.min_version = KMOD_VERSION(0, 11, 5),	/* added libkern patch API */
			.max_version = KMOD_VERSION(0, 11, 5),
		}
	},
})
