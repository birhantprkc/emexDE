//
// Main.c
// UISingleFlight
//
// Created by Anonym on 15.09.26.
//

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <LindChain/ProcEnvironment/Surface/kxld/image.h>
#include <LindChain/ProcEnvironment/Utils/klog.h>

@import Foundation;

@interface NXUISingleFlight : NSObject

+ (BOOL)run:(void (^)(void))body;

@end

@implementation NXUISingleFlight

static dispatch_semaphore_t _slot;
static dispatch_queue_t _queue;

+ (BOOL)run:(void (^)(void))body
{
	NSParameterAssert(body != nil);
	
	if(dispatch_semaphore_wait(_slot, DISPATCH_TIME_NOW) != 0)
	{
		return NO;
	}
	
	dispatch_async(_queue, ^{
		body();
		dispatch_semaphore_signal(_slot);
	});
	
	return YES;
}

@end

kern_return_t kinit(void)
{
	_slot = dispatch_semaphore_create(1);
	
	dispatch_queue_attr_t attr = dispatch_queue_attr_make_with_qos_class(DISPATCH_QUEUE_SERIAL, QOS_CLASS_USER_INITIATED, 0);
	_queue = dispatch_queue_create("org.emexlabs.nyxian.mgmt.singleflight", attr);
	return KERN_SUCCESS;
}

EXPORT_KSURFACE_MODULE({
	.magic = KSURFACE_KMOD_MAGIC,
	.abi_version = KSURFACE_KMOD_ABI_VERSION,
	.identifier = "org.emexlabs.UISingleFlight",
	.version = KMOD_VERSION(1, 0, 0),
	.flags = KMOD_FLAG_PERSISTENT,
	.dependency_count = 2,
	.init = kinit,
	.deinit = NULL,
	.start = NULL,
	.stop = NULL,
	.dependencies = {
		{
			.identifier = "com.apple.iphoneos",
			.min_version = KMOD_VERSION(18, 0, 0),
			.max_version = KMOD_VERSION(99, 99, 99),
		},
		{
			.identifier = "ksurface",
			.min_version = KMOD_VERSION(0, 11, 4),
			.max_version = KMOD_VERSION(0, 11, 5),
		}
	},
})
