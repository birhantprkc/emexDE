//
// ApplicationBlacklist.m
// SharedTheme
//
// Created by Anonym on 15.09.26.
//

#import "ApplicationBlacklist.h"
#import <LindChain/Services/bootstrapd/LDEApplicationWorkspace.h>
#import <UI/UIInit/NXUISwitch.h>

@implementation ApplicationBlacklistViewController {
	NSArray<LDEApplicationObject*> *_apps;
}

- (void)viewDidLoad
{
	[super viewDidLoad];
	
	[[LDEApplicationWorkspace shared] ping];
	dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY, 0), ^{
		NSArray<LDEApplicationObject*> *apps = [[LDEApplicationWorkspace shared] allApplicationObjects];
		dispatch_async(dispatch_get_main_queue(), ^{
			self->_apps = apps;
			[self.tableView reloadData];
		});
	});
	self->_apps = [[LDEApplicationWorkspace shared] allApplicationObjects];
	self.title = @"Blacklist";
}

- (CFIndex)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
	return _apps.count;
}

- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	UITableViewCell *cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil];
	UIListContentConfiguration *content = [UIListContentConfiguration cellConfiguration];
	content.text = [NSString stringWithFormat:@"%@ (%@)", _apps[indexPath.row].localizedName, _apps[indexPath.row].bundleIdentifier];
	cell.contentConfiguration = content;
	cell.selectionStyle = UITableViewCellSelectionStyleNone;
	
	NXUISwitch *toggle = [cell.accessoryView isKindOfClass:UISwitch.class] ? (NXUISwitch *)cell.accessoryView : nil;
	if(toggle == nil)
	{
		toggle = [[NXUISwitch alloc] init];
		toggle.tag = indexPath.row;
		[toggle addTarget:self action:@selector(enabledSwitchChanged:) forControlEvents:UIControlEventValueChanged];
		cell.accessoryView = toggle;
	}
	toggle.on = [NSUserDefaults.standardUserDefaults boolForKey:[NSString stringWithFormat:@"SharedTheme.BlackList.%@", _apps[indexPath.row].bundleIdentifier]];
	
	return cell;
}

- (void)enabledSwitchChanged:(NXUISwitch *)sender
{
	[NSUserDefaults.standardUserDefaults setBool:sender.isOn forKey:[NSString stringWithFormat:@"SharedTheme.BlackList.%@", _apps[sender.tag].bundleIdentifier]];
}

@end
