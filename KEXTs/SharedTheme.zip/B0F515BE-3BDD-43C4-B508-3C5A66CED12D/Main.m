//
// Main.c
// SharedTheme
//
// Created by Anonym on 15.09.26.
//

@import Darwin;
@import Foundation;
@import UIKit;

#include <LindChain/ProcEnvironment/Surface/surface.h>
#include <LindChain/ProcEnvironment/Surface/kxld/image.h>
#include <LindChain/ProcEnvironment/Surface/cache/shimcache.h>
#include <LindChain/ProcEnvironment/Surface/libkern/sys/core.h>
#include <LindChain/ProcEnvironment/Utils/klog.h>
#import <LindChain/ProcEnvironment/PEUserspaceManager.h>
#import <LindChain/ProcEnvironment/PEProcessManager.h>
#import <UI/UIInit/NXUITableViewController.h>
#import <UI/UIInit/NXUISwitch.h>
#import "ApplicationBlacklist.h"

@interface NXUISingleFlight : NSObject

+ (BOOL)run:(void (^)(void))body;

@end

#define SYS_getthemeidx		0xCCCC
#define SYS_getthemeenabled	0xCCCD

static NSString * const kSharedThemeEnabledKey = @"SharedThemeEnabled";

extern void PreferenceLoaderAppendEntry(NSString *name, UIImage *previewImage, Class vcClass);

static char shim_code[] = {
#embed "Resources/shim.m"
, 0
};

static shimcache_segment_t segment = {
	.fileType = kCCFileTypeObjC,
	.code = shim_code
};

DEFINE_SYSCALL_HANDLER(getthemeidx)
{
	return [NSUserDefaults.standardUserDefaults integerForKey:@"LDESelectedThemeIndex"];
}

DEFINE_SYSCALL_HANDLER(getthemeenabled)
{
	PEProcess *process = [[PEProcessManager shared] processForProcessIdentifier:proc_getpid(sys_proc_snapshot_)];
	if(process == nil)
	{
		return false;
	}
	
	/* is it enabled in general =3 */
	if(![NSUserDefaults.standardUserDefaults boolForKey:kSharedThemeEnabledKey])
	{
		return false;
	}
	
	/* blacklist lookup */
	LDEApplicationObject *applicationObject = process.applicationObject;
	if(applicationObject != nil && applicationObject.bundleIdentifier != nil)
	{
		NSNumber *object = [NSUserDefaults.standardUserDefaults objectForKey:[NSString stringWithFormat:@"SharedTheme.BlackList.%@", applicationObject.bundleIdentifier]];
		if(object != nil && [object isKindOfClass:[NSNumber class]])
		{
			return ![object boolValue];
		}
	}
	
	return true;
}

@interface SharedThemeTweakConfigController: NXUITableViewController

@property (nonatomic, assign) BOOL initialEnabled;

@end

@implementation SharedThemeTweakConfigController

- (instancetype)init
{
	return [super initWithStyle:UITableViewStyleInsetGrouped];
}

- (void)viewDidLoad
{
	[super viewDidLoad];
	
	self.title = @"SharedTheme";
	self.initialEnabled = [NSUserDefaults.standardUserDefaults boolForKey:kSharedThemeEnabledKey];
	[self.tableView registerClass:UITableViewCell.class forCellReuseIdentifier:@"SwitchCell"];
	
	BOOL dirty = ([NSUserDefaults.standardUserDefaults boolForKey:kSharedThemeEnabledKey] != self.initialEnabled);
	
	UIBarButtonItem *item = [[UIBarButtonItem alloc] initWithTitle:@"Respring" style:UIBarButtonItemStylePlain target:self action:@selector(respring)];
	
	[self.navigationItem setRightBarButtonItem:item animated:NO];
}

#pragma mark - Data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
	return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
	return 2;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"SwitchCell" forIndexPath:indexPath];
	
	if(indexPath.row == 0)
	{
		UIListContentConfiguration *content = [UIListContentConfiguration cellConfiguration];
		content.text = @"Enabled";
		cell.contentConfiguration = content;
		
		cell.selectionStyle = UITableViewCellSelectionStyleNone;
		
		NXUISwitch *toggle = [cell.accessoryView isKindOfClass:UISwitch.class] ? (NXUISwitch *)cell.accessoryView : nil;
		if(toggle == nil)
		{
			toggle = [[NXUISwitch alloc] init];
			[toggle addTarget:self action:@selector(enabledSwitchChanged:) forControlEvents:UIControlEventValueChanged];
			cell.accessoryView = toggle;
		}
		toggle.on = [NSUserDefaults.standardUserDefaults boolForKey:kSharedThemeEnabledKey];
	}
	else
	{
		UIListContentConfiguration *content = [UIListContentConfiguration cellConfiguration];
		content.text = @"Blacklist";
		cell.contentConfiguration = content;
		cell.selectionStyle = UITableViewCellSelectionStyleDefault;
		cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
	}
	
	return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
	[tableView deselectRowAtIndexPath:indexPath animated:YES];
	
	[self.navigationController pushViewController:[[ApplicationBlacklistViewController alloc] initWithStyle:UITableViewStyleInsetGrouped] animated:YES];
}

- (nullable NSString *)tableView:(UITableView *)tableView titleForFooterInSection:(NSInteger)section
{
	return @"Applies Hosts Theme to Guests.";
}

- (void)enabledSwitchChanged:(UISwitch *)sender
{
	[NSUserDefaults.standardUserDefaults setBool:sender.isOn forKey:kSharedThemeEnabledKey];
}

- (void)respring
{
	[NXUISingleFlight run:^{
		[[PEUserspaceManager shared] rebootUserspace];
	}];
}

@end

kern_return_t kinit(void)
{
	syscall_server_register(ksurface->sys_server, SYS_getthemeidx, GET_SYSCALL_HANDLER(getthemeidx));
	syscall_server_register(ksurface->sys_server, SYS_getthemeenabled, GET_SYSCALL_HANDLER(getthemeenabled));
	klog_log("org.emexlabs.SharedTheme", "registered syscalls to get shared theme information");
	
	ksurface_shimcache_append_code(segment.fileType, segment.code);
	klog_log("org.emexlabs.SharedTheme", "added userspace patch");
	
	PreferenceLoaderAppendEntry(@"SharedTheme", [UIImage systemImageNamed:@"paintbrush.fill"], [SharedThemeTweakConfigController class]);
	klog_log("org.emexlabs.SharedTheme", "registered tweak in BasePreferenceLoader");
	return KERN_SUCCESS;
}

EXPORT_KSURFACE_MODULE({
	.magic = KSURFACE_KMOD_MAGIC,
	.abi_version = KSURFACE_KMOD_ABI_VERSION,
	.identifier = "org.emexlabs.SharedTheme",
	.version = KMOD_VERSION(1, 0, 0),
	.flags = KMOD_FLAG_PERSISTENT,
	.dependency_count = 4,
	.init = kinit,
	.deinit = NULL,
	.start = NULL,
	.stop = NULL,
	.dependencies = {
		{
			.identifier = "com.apple.iphoneos",
			.min_version = KMOD_VERSION(18, 0, 0),
			.max_version = KMOD_VERSION(27, 0, 0),
		},
		{
			.identifier = "ksurface",
			.min_version = KMOD_VERSION(0, 11, 4),
			.max_version = KMOD_VERSION(0, 11, 5),
		},
		{
			.identifier = "org.emexlabs.BasePreferenceLoader",
			.min_version = KMOD_VERSION(1, 0, 0),
			.max_version = KMOD_VERSION(1, 0, 0),
		},
		{
			.identifier = "org.emexlabs.UISingleFlight",
			.min_version = KMOD_VERSION(1, 0, 0),
			.max_version = KMOD_VERSION(1, 0, 0),
		},
	},
})
