//
// ApplicationBlacklist.h
// SharedTheme
//
// Created by Anonym on 15.09.26.
//

#ifndef APPLICATIONBLACKLIST_H
#define APPLICATIONBLACKLIST_H

@import Foundation;
@import UIKit;
#import <UI/UIInit/NXUITableViewController.h>

@interface ApplicationBlacklistViewController: NXUITableViewController
@end

#endif /* APPLICATIONBLACKLIST_H */
