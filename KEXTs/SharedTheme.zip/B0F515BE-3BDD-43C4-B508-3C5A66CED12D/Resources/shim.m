#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <objc/runtime.h>
#include <unistd.h>
#include <stdio.h>
#include <stdatomic.h>
#include <pthread.h>
#include <mach-o/dyld.h>

typedef struct {
	uint32_t platform;
	uint32_t version;
} sharedtheme_dyld_build_version_t;

extern bool dyld_program_sdk_at_least(sharedtheme_dyld_build_version_t version) __attribute__((weak_import));

#ifndef PLATFORM_IOS
#define PLATFORM_IOS 2
#endif

static BOOL SharedThemeHostLinkedAgainstIOS26(void)
{
	if(dyld_program_sdk_at_least != NULL)
	{
		sharedtheme_dyld_build_version_t ios26 = { PLATFORM_IOS, 26 << 16 };
		return dyld_program_sdk_at_least(ios26);
	}
	return NO;
}

extern int64_t liveshim_syscall(uint32_t syscall_num, ...);

UINavigationBarAppearance *SharedThemeNavigationBarAppearance = nil;
UITabBarAppearance *SharedThemeTabBarAppearance = nil;

NSURL *GetBootloaderBundleURL(void)
{
	static NSURL *bootloaderBundleURL = nil;
	static dispatch_once_t once;
	dispatch_once(&once, ^{
		NSString *rootEnv = [NSString stringWithCString:getenv("NXROOT") encoding:NSUTF8StringEncoding];
		NSString *bootloaderBundlePath = [rootEnv stringByAppendingPathComponent:@"boot/bootloader"];
		bootloaderBundleURL = [NSURL fileURLWithPath:bootloaderBundlePath];
	});
	return bootloaderBundleURL;
}

NS_ASSUME_NONNULL_BEGIN

#pragma mark - Highlight names

typedef NS_ENUM(NSUInteger, LDEHighlightName) {
	LDEHighlightNameUnknown = 0,
	LDEHighlightNameComment,
	LDEHighlightNameConstantBuiltin,
	LDEHighlightNameConstantCharacter,
	LDEHighlightNameConstantMacro,
	LDEHighlightNameConstructor,
	LDEHighlightNameFunction,
	LDEHighlightNameFunctionBuiltin,
	LDEHighlightNameFunctionMacro,
	LDEHighlightNameFunctionMacroBuiltin,
	LDEHighlightNameInclude,
	LDEHighlightNameKeyword,
	LDEHighlightNameKeywordCoroutine,
	LDEHighlightNameKeywordFunction,
	LDEHighlightNameKeywordOperator,
	LDEHighlightNameMethod,
	LDEHighlightNameMethodCall,
	LDEHighlightNameNamespace,
	LDEHighlightNameNumber,
	LDEHighlightNameOperator,
	LDEHighlightNameParameter,
	LDEHighlightNameParameterBuiltin,
	LDEHighlightNamePreproc,
	LDEHighlightNameProperty,
	LDEHighlightNamePunctuation,
	LDEHighlightNamePunctuationBracket,
	LDEHighlightNamePunctuationSpecial,
	LDEHighlightNameStorageclass,
	LDEHighlightNameString,
	LDEHighlightNameStringSpecial,
	LDEHighlightNameTag,
	LDEHighlightNameType,
	LDEHighlightNameTypeBuiltin,
	LDEHighlightNameTypeQualifier,
	LDEHighlightNameVariable,
	LDEHighlightNameVariableBuiltin,
	LDEHighlightNameAttribute,
	LDEHighlightNameException,
	LDEHighlightNameTextURI,
};

#pragma mark - LDETheme

@interface LDETheme : NSObject

@property (class, nonatomic, strong, nullable) LDETheme *currentTheme;
@property (class, nonatomic, strong, readonly, nullable) LDETheme *current;

@property (nonatomic, readonly) CGFloat fontSize;
@property (nonatomic, readonly) UIFont *font;
@property (nonatomic, readonly) UIFont *lineNumberFont;

@property (nonatomic, copy, readonly) NSString *name;

@property (nonatomic, strong, readonly) UIColor *textColor;
@property (nonatomic, strong, readonly) UIColor *backgroundColor;

@property (nonatomic, strong, readonly) UIColor *gutterBackgroundColor;
@property (nonatomic, strong, readonly) UIColor *gutterHairlineColor;

@property (nonatomic, strong, readonly) UIColor *lineNumberColor;

@property (nonatomic, strong, readonly) UIColor *selectedLineBackgroundColor;
@property (nonatomic, strong, readonly) UIColor *selectedLinesLineNumberColor;
@property (nonatomic, strong, readonly) UIColor *selectedLinesGutterBackgroundColor;

@property (nonatomic, strong, readonly) UIColor *invisibleCharactersColor;

@property (nonatomic, strong, readonly) UIColor *pageGuideHairlineColor;
@property (nonatomic, strong, readonly) UIColor *pageGuideBackgroundColor;

@property (nonatomic, strong, readonly) UIColor *markedTextBackgroundColor;

@property (nonatomic, strong, readonly) UIColor *colorKeyword;
@property (nonatomic, strong, readonly) UIColor *colorComment;
@property (nonatomic, strong, readonly) UIColor *colorString;
@property (nonatomic, strong, readonly) UIColor *colorNumber;
@property (nonatomic, strong, readonly) UIColor *colorRegex;
@property (nonatomic, strong, readonly) UIColor *colorFunction;
@property (nonatomic, strong, readonly) UIColor *colorOperator;
@property (nonatomic, strong, readonly) UIColor *colorProperty;
@property (nonatomic, strong, readonly) UIColor *colorPunctuation;
@property (nonatomic, strong, readonly) UIColor *colorDirective;
@property (nonatomic, strong, readonly) UIColor *colorType;
@property (nonatomic, strong, readonly) UIColor *colorConstantBuiltin;
@property (nonatomic, strong, readonly) UIColor *colorMethod;
@property (nonatomic, strong, readonly) UIColor *colorVariable;
@property (nonatomic, strong, readonly) UIColor *colorParameter;
@property (nonatomic, strong, readonly) UIColor *colorNamespace;
@property (nonatomic, strong, readonly) UIColor *colorAttribute;
@property (nonatomic, strong, readonly) UIColor *colorInclude;

@property (nonatomic, strong, readonly) UIColor *appLabel;
@property (nonatomic, strong, readonly) UIColor *appTableView;
@property (nonatomic, strong, readonly) UIColor *appTableCell;

- (nullable instancetype)initWithPlistPath:(NSString *)plistPath NS_DESIGNATED_INITIALIZER;
- (instancetype)init NS_UNAVAILABLE;

- (nullable UIColor *)textColorForHighlightName:(NSString *)highlightName;

@end

#pragma mark - LDEThemeReader

@interface LDEThemeReader : NSObject

@property (class, nonatomic, strong, readonly) LDEThemeReader *shared;

@property (nonatomic, copy, readonly) NSArray<LDETheme *> *themes;
@property (nonatomic, assign) NSInteger selectedThemeIndex;

- (nullable LDETheme *)currentlySelectedTheme;

@end

NS_ASSUME_NONNULL_END

static NSString * const kLDEFontSizeKey = @"LDEFontSize";
static NSString * const kLDESelectedThemeIndexKey = @"LDESelectedThemeIndex";

#pragma mark - Highlight names

static NSDictionary<NSString *, NSNumber *> *LDEHighlightNameTable(void)
{
	static NSDictionary<NSString *, NSNumber *> *table = nil;
	static dispatch_once_t onceToken;
	dispatch_once(&onceToken, ^{
		table = @{
			@"comment":                 @(LDEHighlightNameComment),
			@"constant.builtin":        @(LDEHighlightNameConstantBuiltin),
			@"constant.character":      @(LDEHighlightNameConstantCharacter),
			@"constant.macro":          @(LDEHighlightNameConstantMacro),
			@"constructor":             @(LDEHighlightNameConstructor),
			@"function":                @(LDEHighlightNameFunction),
			@"function.builtin":        @(LDEHighlightNameFunctionBuiltin),
			@"function.macro":          @(LDEHighlightNameFunctionMacro),
			@"function.macro.builtin":  @(LDEHighlightNameFunctionMacroBuiltin),
			@"include":                 @(LDEHighlightNameInclude),
			@"keyword":                 @(LDEHighlightNameKeyword),
			@"keyword.coroutine":       @(LDEHighlightNameKeywordCoroutine),
			@"keyword.function":        @(LDEHighlightNameKeywordFunction),
			@"keyword.operator":        @(LDEHighlightNameKeywordOperator),
			@"method":                  @(LDEHighlightNameMethod),
			@"method.call":             @(LDEHighlightNameMethodCall),
			@"namespace":               @(LDEHighlightNameNamespace),
			@"number":                  @(LDEHighlightNameNumber),
			@"operator":                @(LDEHighlightNameOperator),
			@"parameter":               @(LDEHighlightNameParameter),
			@"parameter.builtin":       @(LDEHighlightNameParameterBuiltin),
			@"preproc":                 @(LDEHighlightNamePreproc),
			@"property":                @(LDEHighlightNameProperty),
			@"punctuation":             @(LDEHighlightNamePunctuation),
			@"punctuation.bracket":     @(LDEHighlightNamePunctuationBracket),
			@"punctuation.special":     @(LDEHighlightNamePunctuationSpecial),
			@"storageclass":            @(LDEHighlightNameStorageclass),
			@"string":                  @(LDEHighlightNameString),
			@"string.special":          @(LDEHighlightNameStringSpecial),
			@"tag":                     @(LDEHighlightNameTag),
			@"type":                    @(LDEHighlightNameType),
			@"type.builtin":            @(LDEHighlightNameTypeBuiltin),
			@"type.qualifier":          @(LDEHighlightNameTypeQualifier),
			@"variable":                @(LDEHighlightNameVariable),
			@"variable.builtin":        @(LDEHighlightNameVariableBuiltin),
			@"attribute":               @(LDEHighlightNameAttribute),
			@"exception":               @(LDEHighlightNameException),
			@"text.uri":                @(LDEHighlightNameTextURI),
		};
	});
	return table;
}

LDEHighlightName LDEHighlightNameFromString(NSString *rawHighlightName)
{
	if(rawHighlightName.length == 0)
	{
		return LDEHighlightNameUnknown;
	}
	
	NSMutableArray<NSString *> *components = [NSMutableArray array];
	for(NSString *component in [rawHighlightName componentsSeparatedByString:@"."])
	{
		if(component.length > 0)
		{
			[components addObject:component];
		}
	}
	
	NSDictionary<NSString *, NSNumber *> *table = LDEHighlightNameTable();
	while(components.count > 0)
	{
		NSString *candidate = [components componentsJoinedByString:@"."];
		NSNumber *match = table[candidate];
		if(match != nil)
		{
			return (LDEHighlightName)match.unsignedIntegerValue;
		}
		[components removeLastObject];
	}

    return LDEHighlightNameUnknown;
}

#pragma mark - Color helpers

UIColor *LDENeoRGB(CGFloat red, CGFloat green, CGFloat blue)
{
    return [UIColor colorWithRed:red / 255.0 green:green / 255.0 blue:blue / 255.0 alpha:1.0];
}

UIColor *LDEDynamicColor(UIColor *light, UIColor *dark)
{
	return [UIColor colorWithDynamicProvider:^UIColor *(UITraitCollection *traits) {
		switch(traits.userInterfaceStyle)
		{
			case UIUserInterfaceStyleDark:
				return dark;
			case UIUserInterfaceStyleLight:
			case UIUserInterfaceStyleUnspecified:
				return light;
			default:
				return light;
		}
	}];
}

UIColor *LDEDynamicRGBColor(CGFloat lightRed, CGFloat lightGreen, CGFloat lightBlue, CGFloat darkRed, CGFloat darkGreen, CGFloat darkBlue, CGFloat alpha)
{
	UIColor *light = [LDENeoRGB(lightRed, lightGreen, lightBlue) colorWithAlphaComponent:alpha];
	UIColor *dark = [LDENeoRGB(darkRed, darkGreen, darkBlue) colorWithAlphaComponent:alpha];
	return LDEDynamicColor(light, dark);
}

UIColor *LDERGBStringToColor(NSString *string)
{
	NSMutableArray<NSNumber *> *parts = [NSMutableArray array];
	for(NSString *rawComponent in [string componentsSeparatedByString:@":"])
	{
		NSString *component = [rawComponent stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceAndNewlineCharacterSet];
		if(component.length == 0)
		{
			continue;
		}
		
		NSScanner *scanner = [NSScanner scannerWithString:component];
		double value = 0.0;
		if([scanner scanDouble:&value] && scanner.isAtEnd)
		{
			[parts addObject:@(value)];
		}
	}
	
	if(parts.count != 3)
	{
		NSCAssert(NO, @"Malformed LDE color string: %@", string);
		return UIColor.clearColor;
	}
	
	return LDENeoRGB(parts[0].doubleValue, parts[1].doubleValue, parts[2].doubleValue);
}

UIColor *LDEThemeColorGen(id colorEntry)
{
	if(![colorEntry isKindOfClass:NSDictionary.class])
	{
		return UIColor.clearColor;
	}
	
	NSDictionary *entry = (NSDictionary *)colorEntry;
	id lightEntry = entry[@"light"];
	id darkEntry = entry[@"dark"];
	
	if([lightEntry isKindOfClass:NSString.class] && [darkEntry isKindOfClass:NSString.class])
	{
		return LDEDynamicColor(LDERGBStringToColor((NSString *)lightEntry), LDERGBStringToColor((NSString *)darkEntry));
	}
	
	if([lightEntry isKindOfClass:NSDictionary.class] && [darkEntry isKindOfClass:NSDictionary.class])
	{
		NSDictionary *light = (NSDictionary *)lightEntry;
		NSDictionary *dark = (NSDictionary *)darkEntry;
		
		NSNumber *lightAlpha = [light[@"alpha"] isKindOfClass:NSNumber.class] ? light[@"alpha"] : nil;
		CGFloat alpha = (lightAlpha != nil ? lightAlpha.doubleValue : 10.0) / 10.0;
		
		return LDEDynamicRGBColor([light[@"red"] doubleValue], [light[@"green"] doubleValue], [light[@"blue"] doubleValue], [dark[@"red"] doubleValue], [dark[@"green"] doubleValue], [dark[@"blue"] doubleValue], alpha);
	}
	
	return UIColor.clearColor;
}

@implementation LDETheme

static LDETheme *_LDECurrentTheme = nil;

+ (LDETheme *)currentTheme
{
	return _LDECurrentTheme;
}

+ (void)setCurrentTheme:(LDETheme *)currentTheme
{
	_LDECurrentTheme = currentTheme;
}

+ (LDETheme *)current
{
	return _LDECurrentTheme;
}

- (nullable instancetype)initWithPlistPath:(NSString *)plistPath
{
	self = [super init];
	if(self == nil)
	{
		return nil;
	}
	
	NSData *data = [NSData dataWithContentsOfFile:plistPath];
	if(data == nil)
	{
		return nil;
	}
	
	id plist = [NSPropertyListSerialization propertyListWithData:data options:NSPropertyListImmutable format:NULL error:NULL];
	if(![plist isKindOfClass:NSDictionary.class])
	{
		return nil;
	}
	
	id themeEntry = ((NSDictionary *)plist)[@"LDETheme"];
	if(![themeEntry isKindOfClass:NSDictionary.class])
	{
		return nil;
	}
	NSDictionary *theme = (NSDictionary *)themeEntry;
	
	id appEntry = theme[@"app"];
	id highlightingEntry = theme[@"highlighting"];
	if(![appEntry isKindOfClass:NSDictionary.class] || ![highlightingEntry isKindOfClass:NSDictionary.class])
	{
		return nil;
	}
	NSDictionary *app = (NSDictionary *)appEntry;
	NSDictionary *highlighting = (NSDictionary *)highlightingEntry;
	
	_name = [plistPath.lastPathComponent stringByDeletingPathExtension];
	
	_colorKeyword = LDEThemeColorGen(highlighting[@"keyword"]);
	_colorComment = LDEThemeColorGen(highlighting[@"comment"]);
	_colorString = LDEThemeColorGen(highlighting[@"string"]);
	_colorNumber = LDEThemeColorGen(highlighting[@"number"]);
	_colorRegex = LDEThemeColorGen(highlighting[@"regex"]);
	_colorFunction = LDEThemeColorGen(highlighting[@"function"]);
	_colorOperator = LDEThemeColorGen(highlighting[@"operator"]);
	_colorProperty = LDEThemeColorGen(highlighting[@"property"]);
	_colorPunctuation = LDEThemeColorGen(highlighting[@"punctuation"]);
	_colorDirective = LDEThemeColorGen(highlighting[@"directive"]);
	_colorType = LDEThemeColorGen(highlighting[@"type"]);
	_colorConstantBuiltin = LDEThemeColorGen(highlighting[@"constant"]);
	_colorMethod = LDEThemeColorGen(highlighting[@"method"]);
	_colorVariable = LDEThemeColorGen(highlighting[@"variable"]);
	_colorParameter = LDEThemeColorGen(highlighting[@"parameter"]);
	_colorNamespace = LDEThemeColorGen(highlighting[@"namespace"]);
	_colorAttribute = LDEThemeColorGen(highlighting[@"attribute"]);
	_colorInclude = LDEThemeColorGen(highlighting[@"include"]);
	
	_textColor = LDEThemeColorGen(theme[@"text"]);
	_backgroundColor = LDEThemeColorGen(theme[@"background"]);
	_gutterBackgroundColor = LDEThemeColorGen(theme[@"gutterBackground"]);
	_gutterHairlineColor = LDEThemeColorGen(theme[@"gutterHairline"]);
	_lineNumberColor = LDEThemeColorGen(theme[@"lineNumber"]);
	_selectedLineBackgroundColor = [LDEThemeColorGen(theme[@"selectedLineBackground"]) colorWithAlphaComponent:0.8];
	_selectedLinesLineNumberColor = LDEThemeColorGen(theme[@"selectedLinesLineNumber"]);
	_selectedLinesGutterBackgroundColor = LDEThemeColorGen(theme[@"selectedLinesGutterBackground"]);
	_pageGuideHairlineColor = LDEThemeColorGen(theme[@"pageGuideHairline"]);
	_pageGuideBackgroundColor = LDEThemeColorGen(theme[@"pageGuideBackground"]);
	_markedTextBackgroundColor = LDEThemeColorGen(theme[@"markedTextBackground"]);
	
	_appLabel = LDEThemeColorGen(app[@"appLabel"]);
	_appTableView = LDEThemeColorGen(app[@"appTableViewBackground"]);
	_appTableCell = LDEThemeColorGen(app[@"appTableCellBackground"]);
	
	return self;
}

- (CGFloat)fontSize
{
	NSUserDefaults *defaults = NSUserDefaults.standardUserDefaults;
	if([defaults objectForKey:kLDEFontSizeKey] == nil)
	{
		return 12.0;
	}
	return (CGFloat)[defaults integerForKey:kLDEFontSizeKey];
}

- (UIFont *)font
{
	return [UIFont monospacedSystemFontOfSize:self.fontSize weight:UIFontWeightSemibold];
}

- (UIFont *)lineNumberFont
{
	return [UIFont monospacedSystemFontOfSize:self.fontSize * 0.85 weight:UIFontWeightMedium];
}

- (UIColor *)invisibleCharactersColor
{
	return [self.textColor colorWithAlphaComponent:0.25];
}

- (nullable UIColor *)textColorForHighlightName:(NSString *)highlightName
{
	switch(LDEHighlightNameFromString(highlightName))
	{
		case LDEHighlightNameComment:
			return self.colorComment;
		case LDEHighlightNameKeyword:
		case LDEHighlightNameKeywordOperator:
		case LDEHighlightNameKeywordCoroutine:
		case LDEHighlightNameStorageclass:
		case LDEHighlightNameException:
			return self.colorKeyword;
		case LDEHighlightNameKeywordFunction:
			return self.colorPunctuation;
		case LDEHighlightNameInclude:
		case LDEHighlightNamePreproc:
			return self.colorInclude;
		case LDEHighlightNameType:
		case LDEHighlightNameTypeBuiltin:
		case LDEHighlightNameTypeQualifier:
			return self.colorType;
		case LDEHighlightNameNamespace:
			return self.colorNamespace;
		case LDEHighlightNameFunction:
		case LDEHighlightNameFunctionBuiltin:
		case LDEHighlightNameFunctionMacro:
		case LDEHighlightNameFunctionMacroBuiltin:
			return self.colorFunction;
		case LDEHighlightNameMethod:
		case LDEHighlightNameMethodCall:
		case LDEHighlightNameConstructor:
			return self.colorMethod;
		case LDEHighlightNameVariable:
		case LDEHighlightNameVariableBuiltin:
			return self.colorVariable;
		case LDEHighlightNameParameter:
		case LDEHighlightNameParameterBuiltin:
			return self.colorParameter;
		case LDEHighlightNameProperty:
			return self.colorProperty;
		case LDEHighlightNameAttribute:
			return self.colorAttribute;
		case LDEHighlightNameString:
		case LDEHighlightNameStringSpecial:
		case LDEHighlightNameTag:
			return self.colorString;
		case LDEHighlightNameNumber:
		case LDEHighlightNameTextURI:
			return self.colorNumber;
		case LDEHighlightNameConstantBuiltin:
		case LDEHighlightNameConstantCharacter:
		case LDEHighlightNameConstantMacro:
			return self.colorConstantBuiltin;
		case LDEHighlightNameOperator:
			return self.colorOperator;
		case LDEHighlightNamePunctuation:
		case LDEHighlightNamePunctuationBracket:
		case LDEHighlightNamePunctuationSpecial:
			return self.colorPunctuation;
		case LDEHighlightNameUnknown:
			return nil;
	}
}

@end

@implementation LDEThemeReader

+ (LDEThemeReader *)shared
{
	static LDEThemeReader *shared = nil;
	static dispatch_once_t onceToken;
	dispatch_once(&onceToken, ^{
		shared = [[LDEThemeReader alloc] init];
	});
	return shared;
}

- (instancetype)init
{
	self = [super init];
	if(self == nil)
	{
		return nil;
	}
	
	NSMutableArray<LDETheme *> *themes = [NSMutableArray array];
	NSString *directory = [GetBootloaderBundleURL().path stringByAppendingPathComponent:@"Shared/Themes"];
	NSString *path = [directory stringByAppendingPathComponent:@"Themes.plist"];
	
	NSData *data = [NSData dataWithContentsOfFile:path];
	id plist = data != nil ? [NSPropertyListSerialization propertyListWithData:data options:NSPropertyListImmutable format:NULL error:NULL] : nil;
	
	if([plist isKindOfClass:NSDictionary.class])
	{
		id themeFilesEntry = ((NSDictionary *)plist)[@"LDEThemes"];
		if([themeFilesEntry isKindOfClass:NSArray.class])
		{
			for(id file in (NSArray *)themeFilesEntry)
			{
				if(![file isKindOfClass:NSString.class])
				{
					continue;
				}
				NSString *themePath = [directory stringByAppendingPathComponent:(NSString *)file];
				LDETheme *theme = [[LDETheme alloc] initWithPlistPath:themePath];
				if(theme != nil)
				{
					[themes addObject:theme];
				}
			}
		}
	}
	
	_themes = [themes copy];
	
	if(self.selectedThemeIndex < 0 || self.selectedThemeIndex >= (NSInteger)_themes.count)
	{
		self.selectedThemeIndex = 0;
	}
	
	return self;
}

- (NSInteger)selectedThemeIndex
{
	return (NSInteger)liveshim_syscall(0xCCCC);
}

- (nullable LDETheme *)currentlySelectedTheme
{
	static BOOL available = false;
	static dispatch_once_t once;
	dispatch_once(&once, ^{
		if(liveshim_syscall(0xCCCD) == true)
		{
			available = true;
		}
	});
	
	if(!available)
	{
		return nil;
	}
	
	NSInteger index = self.selectedThemeIndex;
	if(index < 0 || index >= (NSInteger)self.themes.count)
	{
		return nil;
	}
	return self.themes[index];
}

@end

typedef enum: UInt8 {
	kSwizzleReturnSuccess,
	kSwizzleReturnArguments,
	kSwizzleReturnMethodType,
} SwizzleReturn;

typedef enum: UInt8 {
	kSwizzleMethodTypeClass,
	kSwizzleMethodTypeInstance,
	kSwizzleMethodTypeUnknown,
} SwizzleMethodType;

SwizzleReturn SwizzleObjCMethod(SEL originalAction, Class originalClass, SEL replacementAction, Class replacementClass, SwizzleMethodType swizzleMethodType);

@interface UIColor (SharedTheme)
@end

@implementation UIColor (SharedTheme)

+ (UIColor*)hook_systemBlueColor
{
	return [[LDEThemeReader shared] currentlySelectedTheme].appLabel;
}

+ (UIColor*)hook_labelColor
{
	return [[LDEThemeReader shared] currentlySelectedTheme].appLabel;
}

+ (UIColor*)hook_systemBackgroundColor
{
	return [[LDEThemeReader shared] currentlySelectedTheme].backgroundColor;
}

@end

@interface UISwitch (SharedTheme)
@end

@implementation UISwitch (SharedTheme)

static void SharedThemeSwitchApplyTheme(UISwitch *uiSwitch)
{
	LDETheme *theme = [LDEThemeReader.shared currentlySelectedTheme];
	if(uiSwitch == nil || theme == nil)
	{
		return;
	}
	
	uiSwitch.onTintColor = theme.appLabel;
	uiSwitch.thumbTintColor = theme.appTableCell;
}

- (instancetype)initHook
{
	self = [self initHook];
	if(self)
	{
		__weak __typeof(self) weakSelf = self;
		[self registerForTraitChanges:@[UITraitUserInterfaceStyle.class] withHandler:^(id<UITraitEnvironment> traitEnvironment, UITraitCollection *previousCollection) {
			__strong UISwitch *strongSelf = weakSelf;
			SharedThemeSwitchApplyTheme(strongSelf);
		}];
		SharedThemeSwitchApplyTheme(self);
	}
	return self;
}

- (void)hook_setOn:(BOOL)on animated:(BOOL)animated
{
	[self hook_setOn:on animated:animated];
	SharedThemeSwitchApplyTheme(self);
}

- (void)layoutSubviews
{
	[super layoutSubviews];
	SharedThemeSwitchApplyTheme(self);
}

@end

@interface UITableViewController (SharedTheme)
@end

@implementation UITableViewController (SharedTheme)

- (instancetype)initHook
{
	self = [self initHook];
	if(self)
	{
		LDETheme *theme = [LDEThemeReader.shared currentlySelectedTheme];
		self.view.backgroundColor = theme.appTableView;
	}
	return self;
}

- (void)viewDidLoad
{
	[super viewDidLoad];
	LDETheme *theme = [LDEThemeReader.shared currentlySelectedTheme];
	if(theme)
	{
		self.view.backgroundColor = theme.appTableView;
		self.tableView.backgroundColor = theme.appTableView;
		self.tableView.separatorColor = theme.gutterHairlineColor;
	}
}

- (void)viewWillAppear:(BOOL)animated
{
	[super viewWillAppear:animated];
	LDETheme *theme = [LDEThemeReader.shared currentlySelectedTheme];
	if(theme)
	{
		self.view.backgroundColor = theme.appTableView;
	}
}

- (void)viewDidAppear:(BOOL)animated
{
	[super viewDidAppear:animated];
	
	LDETheme *theme = [LDEThemeReader.shared currentlySelectedTheme];
	if(theme)
	{
		self.view.backgroundColor = theme.appTableView;
		self.tableView.separatorColor = theme.gutterHairlineColor;
	}
}

- (void)hook_layoutSubviews
{
	[self hook_layoutSubviews];
	LDETheme *theme = [LDEThemeReader.shared currentlySelectedTheme];
	if(theme)
	{
		self.view.backgroundColor = theme.appTableView;
		self.tableView.separatorColor = theme.gutterHairlineColor;
	}
}

@end

@implementation UIApplication (ProcEnvironment)

- (void)shared_theme_hook_run
{
	/* guest already runs to 100% */
	if(liveshim_syscall(0xCCCD) == true)
	{
		GetBootloaderBundleURL();
		[LDEThemeReader shared];
		
		LDETheme *theme = [LDEThemeReader.shared currentlySelectedTheme];
		if(theme == nil)
		{
			NSLog(@"[sharedtheme] no theme available, skipping appearance setup");
			return;
		}
		
		LDETheme.currentTheme = theme;
		
		/* the typical UIRevert setup */
		/*if(!SharedThemeHostLinkedAgainstIOS26())
		{
			SharedThemeNavigationBarAppearance = [[UINavigationBarAppearance alloc] init];
			SharedThemeNavigationBarAppearance.backgroundColor = theme.gutterBackgroundColor;
			SharedThemeNavigationBarAppearance.titleTextAttributes = @{NSForegroundColorAttributeName: theme.textColor};
			SharedThemeNavigationBarAppearance.buttonAppearance.normal.titleTextAttributes = @{NSForegroundColorAttributeName: theme.textColor};
			SharedThemeNavigationBarAppearance.backButtonAppearance = [[UIBarButtonItemAppearance alloc] init];
			SharedThemeNavigationBarAppearance.backButtonAppearance.normal.titleTextAttributes = @{NSForegroundColorAttributeName: theme.textColor};
			
			SharedThemeTabBarAppearance = [[UITabBarAppearance alloc] init];
			[SharedThemeTabBarAppearance configureWithOpaqueBackground];
			SharedThemeTabBarAppearance.backgroundColor = theme.gutterBackgroundColor;
			
			UINavigationBar.appearance.standardAppearance = SharedThemeNavigationBarAppearance;
			UINavigationBar.appearance.scrollEdgeAppearance = SharedThemeNavigationBarAppearance;
			UINavigationBar.appearance.compactAppearance = SharedThemeNavigationBarAppearance;
			
			UITabBar.appearance.standardAppearance = SharedThemeTabBarAppearance;
			UITabBar.appearance.scrollEdgeAppearance = SharedThemeTabBarAppearance;
		}*/
		
		UITableView.appearance.backgroundColor = theme.appTableView;
		UITableViewCell.appearance.backgroundColor = theme.appTableCell;
		
		[UILabel appearanceWhenContainedInInstancesOfClasses:@[UITableViewCell.class]].textColor = theme.textColor;
		[UILabel appearanceWhenContainedInInstancesOfClasses:@[UIButton.class]].textColor = theme.textColor;
		UIView.appearance.tintColor = theme.appLabel;
		
		/* now the hooks */
		SwizzleObjCMethod(@selector(systemBlueColor), [UIColor class], @selector(hook_systemBlueColor), nil, kSwizzleMethodTypeClass);
		SwizzleObjCMethod(@selector(labelColor), [UIColor class], @selector(hook_labelColor), nil, kSwizzleMethodTypeClass);
		SwizzleObjCMethod(@selector(systemBackgroundColor), [UIColor class], @selector(hook_systemBackgroundColor), nil, kSwizzleMethodTypeClass);
		
		SwizzleObjCMethod(@selector(init), [UISwitch class], @selector(initHook), nil, kSwizzleMethodTypeInstance);
		SwizzleObjCMethod(@selector(setOn:animated:), [UISwitch class], @selector(hook_setOn:animated:), nil, kSwizzleMethodTypeInstance);
		
		SwizzleObjCMethod(@selector(layoutSubview), [UITableViewController class], @selector(hook_layoutSubview), nil, kSwizzleMethodTypeInstance);
		
		//SwizzleObjCMethod(@selector(viewDidLoad), [UIViewController class], @selector(hook_viewDidLoad), nil, kSwizzleMethodTypeInstance);
		//SwizzleObjCMethod(@selector(viewWillAppear), [UIViewController class], @selector(hook_viewWillAppear), nil, kSwizzleMethodTypeInstance);
		//SwizzleObjCMethod(@selector(viewDidAppear), [UIViewController class], @selector(hook_viewDidAppear), nil, kSwizzleMethodTypeInstance);
	}
	
	[self shared_theme_hook_run];
}

@end

__attribute__((constructor))
static void install(void)
{
	SwizzleObjCMethod(@selector(_run), [UIApplication class], @selector(shared_theme_hook_run), nil, kSwizzleMethodTypeInstance);
}
